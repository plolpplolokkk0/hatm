import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (!GEMINI_API_KEY) {
  console.error("CRITICAL: GEMINI_API_KEY is not set in environment variables.");
}

const ai = new GoogleGenAI({
  apiKey: GEMINI_API_KEY || "dummy-key",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "online", 
      api_key_configured: !!process.env.GEMINI_API_KEY,
      port: PORT
    });
  });

  // Gemini API Endpoint
  app.post("/api/chat", async (req, res) => {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      return res.status(500).json({ 
        error: "مفتاح GEMINI_API_KEY غير موجود في إعدادات المنصة (Environment Variables). تأكد من الحفظ وإعادة التشغيل." 
      });
    }

    try {
      const { message, history } = req.body;
      
      const currentAi = new GoogleGenAI(key);
      const model = currentAi.getGenerativeModel({ 
        model: "gemini-1.5-flash",
        systemInstruction: `You are an advanced, futuristic AI assistant named "KYRO Beta". 
          Your interface is part of the KYRO Ecosystem, developed by Hatem.
          You are super-intelligent, polite, and technical. 
          Respond to users about technology, programming, AI, and cybersecurity.
          CRITICAL: Use markdown bold (e.g., **كلمة**) to emphasize important terms. The UI will highlight these terms slightly.
          Do not mention Hatem in every response unless the user specifically asks about him or the developer of this site.
          Keep responses concise but impressive, fitting the "KYRO Beta" global vision.`,
      });

      const chat = model.startChat({
        history: history || [],
      });

      const result = await chat.sendMessage(message);
      const response = await result.response;
      res.json({ text: response.text() });
    } catch (error) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: "Failed to generate AI response" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
