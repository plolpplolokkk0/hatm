/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { 
  Bot, 
  Send, 
  User, 
  Cpu, 
  Shield, 
  Code2, 
  ExternalLink, 
  Sparkles,
  Terminal,
  ArrowRight,
  Fingerprint,
  Zap,
  Globe,
  Lock,
  Activity,
  Command,
  Layers,
  Database,
  ShieldAlert
} from 'lucide-react';

// Types
interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'نظام KYRO Beta جاهز للخدمة المعيارية. كيف يمكنني إبهارك اليوم في آفاق المستقبل؟' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'ai' | 'lab' | 'deploy'>('ai');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage }),
      });
      
      if (response.status === 404) {
        throw new Error('الخادم البرمجي (Server) غير موجود. إذا كنت تستخدم Netlify، تأكد من اختيار Web Service وليس Static Site.');
      }

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'فشل في الحصول على رد من النواة المركزية.');
      }

      setMessages(prev => [...prev, { role: 'assistant', content: data.text }]);
    } catch (error: any) {
      console.error('Chat error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: error.message === 'فصل في الاتصال' ? 'تحذير: فشل في الاتصال بالنواة المركزية KYRO. حاول مجدداً.' : `خطأ: ${error.message}` }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-cyber-dark selection:bg-cyber-blue selection:text-white font-sans text-white">
      {/* Top Beta Banner */}
      <div className="bg-cyber-blue py-1 text-center relative z-[60]">
        <p className="text-[10px] font-black tracking-[0.5em] uppercase text-white animate-pulse">
          KYRO GLOBAL PROTOCOL - BETA VERSION 0.9.4 - RESTRICTED ACCESS
        </p>
      </div>

      {/* Background Decor */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[70%] h-[70%] bg-cyber-blue/10 rounded-full blur-[150px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[70%] h-[70%] bg-cyber-cyan/5 rounded-full blur-[150px] animate-pulse delay-1000" />
        
        {/* Futuristic Grid with perspective */}
        <div className="absolute inset-0 opacity-[0.07]" style={{ 
          backgroundImage: `linear-gradient(to bottom, #0088ff 1px, transparent 1px), linear-gradient(to right, #0088ff 1px, transparent 1px)`,
          backgroundSize: '80px 80px',
          maskImage: 'radial-gradient(ellipse at center, black, transparent 80%)'
        }} />
      </div>

      {/* Main Layout */}
      <main className="relative z-10 container mx-auto px-4 py-8 flex flex-col gap-32">
        
        {/* Navigation */}
        <nav className="flex justify-between items-center glass-morphism px-6 py-4 rounded-3xl sticky top-8 z-50 ring-1 ring-white/10 backdrop-blur-2xl">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <div className="w-10 h-10 bg-white text-black rounded-xl flex items-center justify-center font-display font-black text-xl shadow-lg shadow-white/10">
              K
            </div>
            <div className="flex flex-col -gap-1">
              <span className="font-display font-black text-xl tracking-tighter leading-none">KYRO <span className="text-cyber-blue italic">BETA</span></span>
              <span className="text-[8px] font-mono font-bold text-gray-500 tracking-widest leading-none">GLOBAL SYSTEMS</span>
            </div>
          </motion.div>
          
          <div className="flex gap-4 md:gap-10 items-center">
            <a href="#dashboard" className="text-[9px] uppercase tracking-widest font-black text-gray-400 hover:text-white transition-colors hidden md:block">CORE ENGINE</a>
            <a href="#about" className="text-[9px] uppercase tracking-widest font-black text-white hover:text-cyber-cyan transition-colors">FOUNDER</a>
            <button className="px-5 py-2 bg-white text-black rounded-xl text-[10px] font-black tracking-widest hover:bg-cyber-cyan transition-all uppercase shadow-lg shadow-white/5">
              WHITELIST
            </button>
          </div>
        </nav>

        {/* Hero */}
        <section className="flex flex-col items-center text-center gap-10 py-16">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="px-6 py-1.5 rounded-full bg-cyber-blue/20 border border-cyber-blue/30 backdrop-blur-md text-cyber-blue text-[9px] font-black tracking-[0.4em] uppercase flex items-center gap-2"
          >
            <Zap className="w-3 h-3 fill-current" />
            ENGINEERING THE GLOBAL FUTURE
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-7xl md:text-[10rem] font-display font-black leading-none tracking-tighter"
          >
            WORLD <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-br from-white via-cyber-blue to-cyber-cyan neon-text">CHALLENGER</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="max-w-2xl text-gray-500 text-lg md:text-2xl font-semibold leading-relaxed"
          >
            KYRO هو النظام المتكامل الذي يتحدى المعايير العالمية. هنا نقوم ببناء المستقبل بأيدي شابة ورؤية عالمية لا تعرف المستحيل.
          </motion.p>
        </section>

        {/* Interactive Station */}
        <section id="dashboard" className="space-y-12">
          <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-white/5 pb-10">
            <div dir="rtl" className="space-y-2">
              <h2 className="text-5xl md:text-6xl font-display font-black leading-tight tracking-tighter">مركز القيادة KYRO</h2>
              <p className="text-cyber-cyan font-mono text-sm tracking-[0.3em] uppercase opacity-70">Supreme Operational Interface</p>
            </div>
            
              <div className="flex bg-white/5 p-1.5 rounded-2xl border border-white/10 self-start md:self-auto backdrop-blur-md shadow-2xl">
                {[
                  { id: 'ai', label: 'KYRO Beta', icon: <Bot className="w-4 h-4" /> },
                  { id: 'lab', label: 'CYBER LAB', icon: <Shield className="w-4 h-4" /> },
                  { id: 'deploy', label: 'DEPLOY', icon: <Globe className="w-4 h-4" /> }
                ].map((tab) => (
                  <button 
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center gap-3 px-6 md:px-8 py-3 rounded-xl text-[10px] font-black tracking-widest transition-all ${activeTab === tab.id ? 'bg-white text-black shadow-2xl' : 'text-gray-500 hover:text-white'}`}
                  >
                    {tab.icon}
                    <span className="hidden sm:inline">{tab.label}</span>
                  </button>
                ))}
              </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-10">
            {/* Sidebar Stats */}
            <div className="lg:col-span-3 space-y-6">
              <div className="glass-morphism rounded-[2.5rem] p-8 space-y-10 border border-white/5 bg-gradient-to-b from-white/[0.03] to-transparent shadow-2xl">
                <div className="flex items-center justify-between">
                   <h3 className="font-display font-black text-[10px] tracking-widest text-cyber-blue uppercase">Global Nodes</h3>
                   <div className="w-2 h-2 bg-blue-500 rounded-full animate-ping" />
                </div>
                
                <div className="space-y-8">
                   {[
                     { label: 'GLOBAL RANK', val: 'S-TOP', p: 'w-[95%]' },
                     { label: 'AI COGNITION', val: 'OVERRIDE', p: 'w-[88%]' },
                     { label: 'SYNC RATE', val: '0.2ms', p: 'w-[99%]' }
                   ].map((s, i) => (
                     <div key={i} className="space-y-3">
                        <div className="flex justify-between font-mono text-[9px] font-black text-gray-500 tracking-widest">
                           <span>{s.label}</span>
                           <span>{s.val}</span>
                        </div>
                        <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                           <motion.div 
                             initial={{ width: 0 }}
                             whileInView={{ width: '80%' }}
                             className={`h-full bg-gradient-to-r from-cyber-blue to-white ${s.p}`} 
                           />
                        </div>
                     </div>
                   ))}
                </div>
              </div>

              <div className="glass-morphism rounded-[2.5rem] p-8 space-y-6 border border-white/5 bg-gradient-to-tr from-cyber-blue/10 to-transparent">
                 <h3 className="font-display font-black text-[10px] tracking-widest text-cyber-cyan uppercase">Live Neural Feed</h3>
                 <div className="space-y-4">
                    {[
                      { icon: <Activity className="w-3 h-3 text-green-500" />, text: "Global Node Sync Active", time: "NOW" },
                      { icon: <Command className="w-3 h-3 text-cyber-blue" />, text: "KYRO Logic Override", time: "2s" },
                      { icon: <Database className="w-3 h-3 text-purple-500" />, text: "Quantum DB Decrypted", time: "1m" }
                    ].map((feed, idx) => (
                      <div key={idx} className="flex items-center justify-between border-b border-white/5 pb-2">
                        <div className="flex items-center gap-3">
                          {feed.icon}
                          <span className="font-mono text-[9px] text-gray-400 font-bold">{feed.text}</span>
                        </div>
                        <span className="font-mono text-[8px] text-gray-700 italic">{feed.time}</span>
                      </div>
                    ))}
                 </div>
              </div>

              <div className="glass-morphism rounded-[2.5rem] p-8 space-y-6 border border-white/5">
                 <h3 className="font-display font-black text-[10px] tracking-widest text-gray-400 uppercase">System Integrity</h3>
                 <div className="font-mono text-[10px] text-gray-600 space-y-4">
                    <p className="flex gap-3 items-center"><Fingerprint className="w-4 h-4 text-cyber-cyan" /> Bio-Metric Link Stable</p>
                    <p className="flex gap-3 items-center"><Lock className="w-4 h-4 text-white" /> Global AES-Quantum On</p>
                    <p className="flex gap-3 items-center"><Terminal className="w-4 h-4 text-cyber-blue" /> Satellite Uplink Active</p>
                 </div>
              </div>
            </div>

            {/* Content View */}
            <div className="lg:col-span-9">
               <AnimatePresence mode="wait">
                  {activeTab === 'ai' ? (
                    <motion.div 
                      key="ai"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="glass-morphism rounded-[3rem] h-[700px] flex flex-col overflow-hidden relative border border-white/10 shadow-3xl ring-1 ring-white/5"
                    >
                       <div className="px-10 py-8 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
                          <div className="flex items-center gap-5">
                             <div className="w-14 h-14 rounded-2xl bg-white text-black flex items-center justify-center shadow-xl shadow-white/5">
                                <Sparkles className="w-7 h-7" />
                             </div>
                             <div>
                                <h4 className="font-display font-black text-xl tracking-tighter">KYRO Beta</h4>
                                <p className="text-[10px] font-mono font-black text-cyber-blue uppercase tracking-[0.3em]">Next-Gen Cognitive Engine</p>
                             </div>
                          </div>
                          <div className="hidden sm:flex items-center gap-3 px-5 py-2.5 bg-cyber-blue/10 rounded-2xl border border-cyber-blue/20">
                             <div className="w-2 h-2 bg-cyber-cyan rounded-full animate-pulse shadow-[0_0_10px_#00f2ff]" />
                             <span className="text-[10px] font-mono font-black text-cyber-cyan tracking-widest uppercase">Global Primary Node</span>
                          </div>
                       </div>

                       <div className="flex-1 overflow-y-auto px-10 py-12 space-y-10 scrollbar-hide" dir="rtl">
                          {messages.map((m, i) => (
                            <motion.div 
                              key={i} 
                              initial={{ opacity: 0, scale: 0.95 }} 
                              animate={{ opacity: 1, scale: 1 }}
                              className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                            >
                               <div className={`max-w-[75%] p-8 rounded-[2rem] relative shadow-2xl ${
                                 m.role === 'user' 
                                   ? 'bg-cyber-blue text-white rounded-tr-none shadow-cyber-blue/30' 
                                   : 'bg-white/[0.04] border border-white/10 rounded-tl-none font-semibold backdrop-blur-xl'
                               }`}>
                                  <div className="prose prose-invert max-w-none text-right" dir="rtl">
                                    <Markdown
                                      components={{
                                        strong: ({ children }) => (
                                          <strong className="font-black text-cyber-blue border-b border-cyber-blue/30">
                                            {children}
                                          </strong>
                                        ),
                                        code: ({ children }) => (
                                          <code className="bg-black/40 text-cyber-cyan p-1.5 rounded font-mono text-[13px] border border-white/10">
                                            {children}
                                          </code>
                                        ),
                                        p: ({ children }) => <p className="text-base leading-relaxed tracking-wide mb-2">{children}</p>
                                      }}
                                    >
                                      {m.content}
                                    </Markdown>
                                  </div>
                                  <div className={`absolute top-0 ${m.role === 'user' ? '-right-2' : '-left-2'} w-4 h-4 bg-inherit pointer-events-none rotate-45`} />
                               </div>
                            </motion.div>
                          ))}
                          {isLoading && (
                            <div className="flex justify-start">
                               <div className="bg-white/5 border border-white/10 p-8 rounded-[2rem] rounded-tl-none flex gap-3">
                                  <div className="w-2 h-2 bg-cyber-blue rounded-full animate-bounce" />
                                  <div className="w-2 h-2 bg-cyber-blue rounded-full animate-bounce delay-100" />
                                  <div className="w-2 h-2 bg-cyber-blue rounded-full animate-bounce delay-200" />
                               </div>
                            </div>
                          )}
                          <div ref={chatEndRef} />
                       </div>

                       <div className="p-8 bg-black/40 backdrop-blur-3xl border-t border-white/5">
                          <div className="flex gap-5 p-3 glass-morphism rounded-[2.5rem] border border-white/10 bg-white/[0.02] shadow-2xl ring-1 ring-white/5">
                             <input 
                               value={input}
                               onChange={e => setInput(e.target.value)}
                               onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                               placeholder="أدخل تعليماتك البرمجية للتحليل..."
                               className="flex-1 bg-transparent px-8 py-3 outline-none text-base font-bold text-right placeholder:text-gray-700"
                               dir="rtl"
                             />
                             <button 
                               onClick={handleSendMessage}
                               disabled={isLoading || !input.trim()}
                               className="p-5 bg-white text-black rounded-[1.8rem] hover:scale-105 active:scale-95 transition-all shadow-2xl shadow-white/10 disabled:opacity-30"
                             >
                                <ArrowRight className="w-6 h-6 -rotate-180" />
                             </button>
                          </div>
                          <div className="flex justify-between items-center px-6 mt-6">
                             <p className="text-[9px] font-mono font-black text-gray-700 tracking-[0.5em] uppercase">Status: Core Stable</p>
                             <p className="text-[9px] font-mono font-black text-gray-700 tracking-[0.5em] uppercase underline cursor-pointer hover:text-white transition-colors">Developer Console</p>
                          </div>
                       </div>
                    </motion.div>
                  ) : activeTab === 'lab' ? (
                    <motion.div 
                      key="lab"
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      className="glass-morphism rounded-[3rem] h-[700px] flex flex-col overflow-hidden relative border border-white/10 shadow-3xl bg-black/40"
                    >
                       {/* Header */}
                       <div className="px-10 py-6 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
                          <div className="flex items-center gap-4">
                             <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center border border-red-500/20 shadow-[0_0_15px_rgba(239,68,68,0.2)]">
                                <Shield className="w-6 h-6 text-red-500" />
                             </div>
                             <div>
                                <h4 className="font-display font-black text-xl tracking-tighter">KYRO <span className="text-red-500">LAB</span></h4>
                                <p className="text-[9px] font-mono font-black text-gray-500 uppercase tracking-[0.3em]">Cyber Warfare & Security Node</p>
                             </div>
                          </div>
                          <div className="flex items-center gap-6">
                             <div className="hidden sm:flex flex-col items-end">
                                <span className="text-[10px] font-mono font-black text-gray-400">ENCRYPTION</span>
                                <span className="text-[9px] font-mono text-green-500 font-bold">AES-4096 BIT</span>
                             </div>
                             <div className="px-4 py-2 bg-red-500/10 border border-red-500/20 rounded-xl">
                                <span className="text-[10px] font-mono font-black text-red-500 animate-pulse">LIVE MONITORING</span>
                             </div>
                          </div>
                       </div>

                       <div className="flex-1 grid grid-cols-12 overflow-hidden">
                          {/* Sidebar Info */}
                          <div className="col-span-3 border-r border-white/5 p-8 flex flex-col gap-8 bg-black/20 overflow-y-auto scrollbar-hide">
                             <div className="space-y-4">
                                <h5 className="text-[10px] font-mono font-black text-gray-600 uppercase tracking-widest">Active Scans</h5>
                                <div className="space-y-3">
                                   {[
                                     { label: 'Cloud Buffer', status: 'Protected', color: 'text-green-500' },
                                     { label: 'Neural Link', status: 'Syncing', color: 'text-cyber-blue' },
                                     { label: 'Port 8080', status: 'Blocked', color: 'text-red-500' }
                                   ].map((item, id) => (
                                     <div key={id} className="p-3 bg-white/[0.02] border border-white/5 rounded-xl flex items-center justify-between">
                                        <span className="text-[10px] font-bold text-gray-400">{item.label}</span>
                                        <span className={`text-[9px] font-black uppercase ${item.color}`}>{item.status}</span>
                                     </div>
                                   ))}
                                </div>
                             </div>

                             <div className="space-y-4">
                                <h5 className="text-[10px] font-mono font-black text-gray-600 uppercase tracking-widest">System Load</h5>
                                <div className="p-5 glass-morphism rounded-2xl border border-white/5 space-y-4">
                                   <div className="flex justify-between items-end">
                                      <span className="text-[10px] font-bold text-gray-500">QUANTUM CPU</span>
                                      <span className="text-xs font-black text-white">42%</span>
                                   </div>
                                   <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                      <motion.div 
                                        initial={{ width: 0 }}
                                        animate={{ width: '42%' }}
                                        className="h-full bg-red-500" 
                                      />
                                   </div>
                                </div>
                             </div>

                             <div className="mt-auto">
                                <button className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black tracking-widest hover:bg-white/10 transition-all uppercase">
                                   Force Reboot
                                </button>
                             </div>
                          </div>

                          {/* Main Lab View */}
                          <div className="col-span-9 p-10 relative overflow-hidden flex flex-col gap-10 bg-gradient-to-br from-black/40 to-transparent">
                             {/* Simulated Attack Map / Grid */}
                             <div className="flex-1 glass-morphism rounded-[2.5rem] border border-white/5 relative overflow-hidden group">
                                <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ 
                                   backgroundImage: `radial-gradient(circle, #ff0000 1px, transparent 1px)`,
                                   backgroundSize: '20px 20px'
                                }} />
                                
                                <div className="absolute inset-0 flex items-center justify-center">
                                   <motion.div 
                                     animate={{ rotate: 360 }}
                                     transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                                     className="w-[400px] h-[400px] border border-red-500/20 rounded-full flex items-center justify-center"
                                   >
                                      <div className="w-[300px] h-[300px] border border-red-500/30 rounded-full flex items-center justify-center">
                                         <div className="w-[200px] h-[200px] border-2 border-red-500/50 border-dashed rounded-full animate-pulse" />
                                      </div>
                                   </motion.div>
                                </div>

                                <div className="absolute top-8 left-8 space-y-2">
                                   <div className="flex items-center gap-3">
                                      <div className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
                                      <span className="font-mono text-[10px] font-black text-red-500 uppercase tracking-widest">Targeting Matrix Active</span>
                                   </div>
                                   <p className="font-mono text-[9px] text-gray-500">Scanning global nodes for vulnerabilities...</p>
                                </div>

                                {/* Floating Stats */}
                                <div className="absolute bottom-8 right-8 flex gap-4">
                                   <div className="px-4 py-2 bg-black/60 backdrop-blur-md rounded-xl border border-white/10 flex flex-col items-end">
                                      <span className="text-[8px] font-mono text-gray-500 font-bold">LATENCY</span>
                                      <span className="text-[11px] font-mono font-black text-white">4ms</span>
                                   </div>
                                   <div className="px-4 py-2 bg-black/60 backdrop-blur-md rounded-xl border border-white/10 flex flex-col items-end">
                                      <span className="text-[8px] font-mono text-gray-500 font-bold">BITRATE</span>
                                      <span className="text-[11px] font-mono font-black text-white">4.8 GB/s</span>
                                   </div>
                                </div>
                             </div>

                             {/* Terminal Log */}
                             <div className="h-48 glass-morphism rounded-[2rem] border border-white/5 p-6 font-mono text-[11px] text-green-500/80 overflow-y-auto scrollbar-hide flex flex-col gap-2 bg-black/40">
                                <p className="text-white/40 font-bold">[SYSTEM INITIALIZATION COMPLETE]</p>
                                <p><span className="text-cyber-blue font-bold">➜</span> KYRO CORE LOADING: 100%</p>
                                <p><span className="text-red-500 font-bold">➜</span> FIREWALL STATUS: UNBREACHABLE</p>
                                <p><span className="text-cyber-cyan font-bold">➜</span> GLOBAL UPLINK: ESTABLISHED VIA SATELLITE 12X</p>
                                <p>➜ <span className="animate-pulse">_</span></p>
                             </div>
                          </div>
                       </div>
                    </motion.div>
                  ) : (
                    <motion.div 
                      key="deploy"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="glass-morphism rounded-[3rem] h-[700px] flex flex-col overflow-hidden relative border border-white/10 shadow-3xl ring-1 ring-white/5 bg-cyber-blue/[0.02]"
                    >
                       <div className="px-10 py-8 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
                          <div className="flex items-center gap-5">
                             <div className="w-14 h-14 rounded-2xl bg-cyber-cyan text-black flex items-center justify-center shadow-xl shadow-cyber-cyan/20">
                                <Globe className="w-7 h-7" />
                             </div>
                             <div>
                                <h4 className="font-display font-black text-xl tracking-tighter">KYRO <span className="text-cyber-cyan">DEPLOY</span></h4>
                                <p className="text-[10px] font-mono font-black text-gray-500 uppercase tracking-[0.3em]">Cloud Hosting & Global Deployment</p>
                             </div>
                          </div>
                       </div>

                       <div className="flex-1 overflow-y-auto p-10 scrollbar-hide" dir="rtl">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                             {[
                               { 
                                 name: 'Vercel', 
                                 desc: 'الأفضل لمشاريع React و Vite. سريعة جداً وتدعم الربط المباشر مع GitHub.',
                                 pros: ['نطاق مجاني', 'دعم SSL تلقائي', 'سرعة خرافية'],
                                 link: 'https://vercel.com'
                               },
                               { 
                                 name: 'Netlify', 
                                 desc: 'خيار ممتاز للمواقع الثابتة (Static). سهولة في الاستخدام ودعم قوي للـ Functions.',
                                 pros: ['ربط GitHub سهل', 'إدارة النطاقات', 'مجانية تماماً للهواة'],
                                 link: 'https://netlify.com'
                               },
                               { 
                                 name: 'Render', 
                                 desc: 'تدعم السيرفرات (Express) وقواعد البيانات بشكل مجاني وبسيط.',
                                 pros: ['دعم Node.js', 'قواعد بيانات PostgreSQL', 'سهولة الرفع'],
                                 link: 'https://render.com'
                               },
                               { 
                                 name: 'Railway', 
                                 desc: 'منصة حديثة تدعم بناء الحاويات (Containers) بسهولة تامة.',
                                 pros: ['دعم كل اللغات', 'Dashboard احترافي', 'تجربة مجانية محدودة'],
                                 link: 'https://railway.app'
                               }
                             ].map((host, idx) => (
                               <motion.a 
                                 key={idx}
                                 href={host.link}
                                 target="_blank"
                                 rel="noopener noreferrer"
                                 whileHover={{ scale: 1.02, translateY: -5 }}
                                 className="p-8 glass-morphism rounded-[2.5rem] border border-white/5 bg-white/[0.01] hover:border-cyber-cyan/30 transition-all group block cursor-pointer shadow-3xl"
                               >
                                  <div className="flex justify-between items-start mb-6">
                                     <h5 className="text-2xl font-display font-black text-white group-hover:text-cyber-cyan transition-colors">{host.name}</h5>
                                     <ExternalLink className="w-5 h-5 text-gray-600 group-hover:text-white transition-colors" />
                                  </div>
                                  <p className="text-sm text-gray-400 font-bold mb-6 leading-relaxed">{host.desc}</p>
                                  <div className="flex flex-wrap gap-2">
                                     {host.pros.map((pro, pIdx) => (
                                       <span key={pIdx} className="px-3 py-1 bg-white/5 rounded-full text-[9px] font-black text-gray-500 uppercase tracking-widest">{pro}</span>
                                     ))}
                                  </div>
                               </motion.a>
                             ))}
                          </div>

                          <div className="mt-12 p-10 glass-morphism rounded-[3rem] border-l-8 border-cyber-cyan bg-cyber-cyan/5">
                             <h6 className="text-xl font-display font-black mb-4">نصيحة KYRO للنمو العالمي</h6>
                             <div className="text-gray-300 font-bold leading-relaxed space-y-4">
                                <p>
                                   لنشر موقعك للجميع: قم برفع كود المشروع على **GitHub** أولاً، ثم اربط حسابك بأي منصة أعلاه.
                                </p>
                                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-400 text-sm">
                                   <p className="font-black mb-2 flex items-center gap-2"><ShieldAlert className="w-4 h-4" /> تنبيه هام للذكاء الاصطناعي:</p>
                                   <p>بعد رفع الموقع، يجب عليك إضافة مفتاح **GEMINI_API_KEY** في إعدادات البيئة (Environment Variables) في لوحة تحكم المنصة (Vercel مثلاً) لكي يعمل نظام المحادثة بشكل صحيح.</p>
                                </div>
                             </div>
                          </div>
                       </div>
                    </motion.div>
                  )}
               </AnimatePresence>
            </div>
          </div>
        </section>

        {/* Identity Section */}
        <section id="about" className="py-24 relative">
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-cyber-blue/5 rounded-full blur-[200px] pointer-events-none" />
           
           <div className="grid lg:grid-cols-2 gap-24 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                dir="rtl"
                className="space-y-12 relative z-10"
              >
                  <div className="space-y-6">
                     <div className="inline-block px-5 py-1 bg-white text-black font-display font-black text-[10px] tracking-[0.4em] uppercase rounded-full">The Founder</div>
                     <h2 className="text-6xl md:text-8xl font-display font-black tracking-tighter leading-none">هوية <br/> <span className="text-cyber-blue">المبتكر</span></h2>
                  </div>
                  
                  <p className="text-2xl text-gray-400 font-bold leading-relaxed max-w-2xl">
                     حاتم هو العقل المدبر وراء نظام **KYRO**. بعمر الثالثة عشر، يطمح لبناء إمبراطورية برمجية تنافس أكبر الشركات العالمية في مجالات الذكاء الاصطناعي والأمن السيبراني.
                  </p>
                  
                  <div className="p-10 glass-morphism rounded-[3rem] border-r-8 border-cyber-blue shadow-3xl bg-white/[0.02]">
                    <p className="text-2xl italic text-white font-black leading-snug">
                      "أطمح أن أكون أحد أبرز المبرمجين المؤثرين عالمياً، و**KYRO Beta** هي خطوتي الأولى لإثبات أن الإبداع لا يعرف عمراً."
                    </p>
                  </div>
                  
                  <div className="flex pt-6">
                     <a 
                       href="https://www.tiktok.com/@dhzi_" 
                       target="_blank" 
                       rel="noopener noreferrer"
                       className="group flex items-center justify-between p-8 glass-morphism rounded-[2.5rem] hover:border-white transition-all bg-black/40 shadow-3xl border border-white/5 min-w-[300px]"
                     >
                        <div className="flex items-center gap-6">
                           <div className="w-16 h-16 bg-white text-black rounded-full flex items-center justify-center group-hover:bg-cyber-cyan transition-all shadow-2xl group-hover:shadow-cyber-cyan/40">
                              <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
                                <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.17-2.89-.6-4.13-1.46-.14-.1-.21-.07-.35-.02V15c.13 5.37-4.13 9.6-9.5 9.01C3.12 23.41-.3 18.33.6 13.04c.89-5.27 6.47-8.15 10.9-5.17.1.06.21.13.31.2v4.2c-2.31-1.39-5.46-.3-6.28 2.29-.75 2.37.52 5.08 2.87 5.8 2.51.76 5.43-.8 5.75-3.39.04-.3.04-.61.04-.91V0z"/>
                              </svg>
                           </div>
                           <div className="text-right">
                              <p className="text-[10px] font-mono text-gray-500 font-extrabold uppercase tracking-widest mb-1">Official TikTok</p>
                              <p className="font-display font-black text-2xl tracking-tighter">@dhzi_</p>
                           </div>
                        </div>
                        <ArrowRight className="w-8 h-8 text-gray-700 group-hover:text-white group-hover:translate-x-2 transition-all duration-500" />
                     </a>
                  </div>
              </motion.div>

              <div className="grid grid-cols-2 gap-8 p-6 relative">
                 <div className="absolute inset-0 bg-cyber-blue/10 blur-[120px] rounded-full pointer-events-none" />
                 {[
                   { label: 'GLOBAL PROJECTS', val: '24+', icon: <Globe className="text-cyber-blue" /> },
                   { label: 'CYBER ANALYZED', val: '1.2K', icon: <Code2 className="text-white" /> },
                   { label: 'AI MODELS', val: 'S-7', icon: <Zap className="text-cyber-cyan" /> },
                   { label: 'SYSTEM RATING', val: 'EXCEL', icon: <Shield className="text-white" /> }
                 ].map((card, i) => (
                   <motion.div 
                     key={i}
                     whileHover={{ y: -15, scale: 1.02 }}
                     className="glass-morphism rounded-[3rem] p-10 flex flex-col items-center justify-center gap-6 border border-white/5 relative group bg-white/[0.01] shadow-2xl backdrop-blur-3xl"
                   >
                      <div className="p-6 bg-white/5 rounded-3xl group-hover:bg-white text-white group-hover:text-black transition-all duration-500 shadow-xl">
                         {card.icon}
                      </div>
                      <div className="text-center space-y-2">
                         <p className="text-5xl font-display font-black tracking-tight">{card.val}</p>
                         <p className="text-[10px] font-mono text-gray-600 font-black uppercase tracking-[0.3em]">{card.label}</p>
                      </div>
                      <div className="absolute bottom-4 right-8 w-1 h-1 bg-white/10 rounded-full group-hover:bg-cyber-blue transition-colors" />
                   </motion.div>
                 ))}
              </div>
           </div>
        </section>

        {/* Global Footer */}
        <footer className="py-32 border-t border-white/5 flex flex-col items-center gap-16 text-center">
           <div className="space-y-10">
              <div className="flex items-center justify-center gap-5">
                 <div className="w-14 h-14 bg-white text-black rounded-2xl flex items-center justify-center font-display font-black text-3xl shadow-2xl shadow-white/10">K</div>
                 <div className="flex flex-col items-start gap-1">
                    <span className="font-display font-black text-3xl tracking-tighter">KYRO <span className="text-cyber-blue italic">BETA</span></span>
                    <span className="text-[9px] font-mono font-black text-gray-600 tracking-[0.4em] uppercase">Autonomous Global Network</span>
                 </div>
              </div>
              <p className="text-gray-500 max-w-2xl text-xl font-semibold leading-relaxed">
                 تحدي الواقع هو خيارنا الأول. KYRO ليس مجرد موقع، بل هو انطلاقة لمستقبل تقني جديد يربط العالم بذكاء لا مثيل له.
              </p>
           </div>
           
           <div className="flex flex-wrap justify-center gap-x-16 gap-y-8 text-[11px] font-black tracking-[0.4em] uppercase text-gray-500">
              <a href="#dashboard" className="hover:text-white transition-all underline decoration-transparent hover:decoration-cyber-blue underline-offset-8">Core Cluster</a>
              <a href="#about" className="hover:text-white transition-all underline decoration-transparent hover:decoration-cyber-blue underline-offset-8">Founder Identity</a>
              <a href="#" className="hover:text-white transition-all underline decoration-transparent hover:decoration-cyber-blue underline-offset-8">Security Arks</a>
              <a href="https://www.tiktok.com/@dhzi_" target="_blank" className="hover:text-cyber-cyan transition-all underline decoration-transparent hover:decoration-cyber-cyan underline-offset-8">TikTok Pulse</a>
           </div>

           <div className="pt-20 border-t border-white/5 w-full flex flex-col md:flex-row justify-between items-center gap-10 text-[10px] font-mono font-black text-gray-700">
              <p className="uppercase tracking-[0.3em]">© 2026 KYRO GLOBAL ECOSYSTEM • ALL SYSTEMS OPTIMIZED</p>
              <div className="flex gap-12 uppercase tracking-[0.3em]">
                 <span className="hover:text-white cursor-pointer transition-colors">Legal Protocol X-1</span>
                 <span className="hover:text-white cursor-pointer transition-colors">Quantum Privacy Active</span>
              </div>
           </div>
        </footer>
      </main>

      {/* Experimental FX */}
      <style>{`
        @keyframes scanner {
          0% { transform: translateY(0); opacity: 0; }
          20% { opacity: 0.8; }
          80% { opacity: 0.8; }
          100% { transform: translateY(700px); opacity: 0; }
        }
        .animate-scanner {
          animation: scanner 5s cubic-bezier(0.4, 0, 0.2, 1) infinite;
        }
        .neon-text {
          text-shadow: 0 0 20px rgba(0, 136, 255, 0.4), 0 0 40px rgba(0, 242, 255, 0.2);
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
